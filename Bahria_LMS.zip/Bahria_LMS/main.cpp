#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    // --- PROFESSIONAL THEME Styling ---
    a.setStyleSheet(
        // 1. MAIN BACKGROUND (Formal Blue Gradient)
        "QMainWindow { "
        "   background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #141E30, stop:1 #243B55); "
        "}"

        // 2. LOGIN CARD (Clean White with Soft Look)
        "QFrame#loginFrame, QFrame#regFrame { "
        "   background-color: #FFFFFF; " // White Background
        "   border-radius: 12px; "       // Rounded Corners
        "   border: 1px solid #DCDCDC; " // Halki si border
        "}"

        // --- TEXT LABELS ---
        "QLabel { font-family: 'Segoe UI', sans-serif; color: #333333; }"
        "QLabel#lblTitle, QLabel#lblRegTitle { "
        "   font-size: 24px; font-weight: bold; color: #003366; margin-bottom: 15px; " // Dark Navy Text
        "}"

        // --- INPUT FIELDS (Professional Greyish) ---
        "QLineEdit { "
        "   border: 1px solid #CCCCCC; "
        "   border-radius: 6px; "
        "   padding: 10px; "
        "   font-size: 14px; "
        "   background-color: #F9F9F9; " // Thora sa grey
        "   color: #333333; "
        "}"
        "QLineEdit:focus { border: 2px solid #0056b3; background-color: #FFFFFF; }"

        // --- BUTTONS (Apke Hover waly rang) ---
        // --- BUTTONS (Admin Buttons Fixed) ---
        "QPushButton { "
        "   background-color: #0056b3; "   // Blue Background (Wapis aa gaya)
        "   color: white; "                // White Text
        "   border-radius: 6px; "
        "   font-size: 14px; "
        "   font-weight: bold; "
        "   padding: 10px; "               // Thora size bara kiya
        "}"
        "QPushButton:hover { background-color: #004494; }" // Dark Blue on Hover

        // Links (Login/Register waly) inka background transparent hi rahega
        "QPushButton#btnGoToRegister, QPushButton#btnBackToLogin { "
        "   background-color: transparent; color: #FFFFFF; text-decoration: underline; "
        "}"

        // --- LISTS & TABS (Dashboard k liye) ---
        "QListWidget { border: 1px solid #ccc; border-radius: 5px;font-size: 14px; background-color: white; color: black; }"
        "QTabWidget::pane { border: 1px solid #ccc; font-size: 14px;background: white; }"

        // --- POPUP FIXES ---
        "QMessageBox { background-color: white; }"
        "QMessageBox QLabel { color: #333333; }"
        "QInputDialog { background-color: white; }"
        "QInputDialog QLabel { color: #333333; }"
        "QInputDialog QLineEdit { background-color: #F0F0F5; color: #333333; border: 1px solid #ccc; }"
        // --- DASHBOARD HEADERS (Student, Teacher, Admin) FIX ---
        // 2. HEADINGS (Dashboard & Main Login Screen)
        "QLabel#lblS, QLabel#lblT, QLabel#lblAdminHead, QLabel#lblMainHead { "
        "   color: #FFFFFF; "                  // White Text
        "   font-size: 32px; "                 // Bara size
        "   font-weight: bold; "               // Mota text
        "   qproperty-alignment: AlignCenter; "// Center
        "   padding-bottom: 20px; "            // Gap neeche
        "}"
        );

    MainWindow w;
    w.show();
    return a.exec();
}
