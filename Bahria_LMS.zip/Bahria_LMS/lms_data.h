#ifndef LMS_DATA_H
#define LMS_DATA_H

#include <iostream>
#include <string>
#include <vector>
#include <QString>
#include <fstream>
#include <sstream>
#include <algorithm> // For remove_if

using namespace std;

// Helpers
inline string qstrToStd(QString s) { return s.toStdString(); }
inline QString stdToQstr(string s) { return QString::fromStdString(s); }

// --- CLASSES ---

class User {
public:
    string id, name, username, password, roleType;

    string toFileString() {
        return id + "|" + name + "|" + username + "|" + password + "|" + roleType;
    }

    void fromFileString(string line) {
        stringstream ss(line);
        string segment;
        vector<string> seglist;
        while(getline(ss, segment, '|')) seglist.push_back(segment);
        if(seglist.size() >= 5) {
            id = seglist[0]; name = seglist[1]; username = seglist[2];
            password = seglist[3]; roleType = seglist[4];
        }
    }
};

class Course {
public:
    string code, name, teacherID;
    vector<string> enrolledStudents;
    vector<string> lectures;     // New: List of lectures
    vector<string> assignments;  // New: List of assignments
    vector<string> grades;       // New: Format "StudentID:Grade"
    vector<string> attendance;   // New: Format "Date:StudentID:Status"

    string toFileString() {
        // Format: Code|Name|TeacherID|Stud1,Stud2|Lec1,Lec2|Ass1,Ass2|Grd1,Grd2|Att1,Att2
        string base = code + "|" + name + "|" + teacherID + "|";

        // Students
        for(const string& s : enrolledStudents) base += s + ",";
        base += "|";
        // Lectures
        for(const string& l : lectures) base += l + ",";
        base += "|";
        // Assignments
        for(const string& a : assignments) base += a + ",";
        base += "|";
        // Grades
        for(const string& g : grades) base += g + ",";
        base += "|";
        // Attendance
        for(const string& at : attendance) base += at + ",";

        return base;
    }

    void fromFileString(string line) {
        stringstream ss(line);
        string segment;
        vector<string> parts;
        while(getline(ss, segment, '|')) parts.push_back(segment);

        if(parts.size() >= 3) {
            code = parts[0]; name = parts[1]; teacherID = parts[2];

            auto splitAndStore = [](string data, vector<string> &vec) {
                stringstream ss2(data); string item;
                while(getline(ss2, item, ',')) if(!item.empty()) vec.push_back(item);
            };

            if(parts.size() > 3) splitAndStore(parts[3], enrolledStudents);
            if(parts.size() > 4) splitAndStore(parts[4], lectures);
            if(parts.size() > 5) splitAndStore(parts[5], assignments);
            if(parts.size() > 6) splitAndStore(parts[6], grades);
            if(parts.size() > 7) splitAndStore(parts[7], attendance);
        }
    }
};

class LMS {
public:
    vector<User> users;
    vector<Course> courses;
    const string USER_FILE = "lms_users_final.txt";   // Naam badal diya
    const string COURSE_FILE = "lms_courses_final.txt";
    LMS() {
        loadData();
        if(users.empty()) registerUser("A-001", "Haji Arsalan ", "haji", "haji123", "Admin");
    }

    // --- DATA HANDLING ---
    void loadData() {
        users.clear(); courses.clear();
        ifstream uFile(USER_FILE); string line;
        while (getline(uFile, line)) { User u; u.fromFileString(line); users.push_back(u); }
        uFile.close();

        ifstream cFile(COURSE_FILE);
        while (getline(cFile, line)) { Course c; c.fromFileString(line); courses.push_back(c); }
        cFile.close();
    }

    void saveData() {
        ofstream uFile(USER_FILE);
        for (User &u : users) uFile << u.toFileString() << endl;
        uFile.close();

        ofstream cFile(COURSE_FILE);
        for (Course &c : courses) cFile << c.toFileString() << endl;
        cFile.close();
    }

    // --- USER MANAGEMENT ---
    bool registerUser(string id, string name, string u, string p, string role) {
        for(User &existing : users) if(existing.username == u || existing.id == id) return false;
        User newUser; newUser.id = id; newUser.name = name; newUser.username = u; newUser.password = p; newUser.roleType = role;
        users.push_back(newUser); saveData(); return true;
    }

    bool removeUser(string id) {
        auto it = remove_if(users.begin(), users.end(), [&](User& u){ return u.id == id; });
        if(it != users.end()) { users.erase(it, users.end()); saveData(); return true; }
        return false;
    }

    User* login(string u, string p, string role) {
        for (int i = 0; i < users.size(); i++)
            if (users[i].username == u && users[i].password == p && users[i].roleType == role) return &users[i];
        return nullptr;
    }

    // --- COURSE MANAGEMENT ---
    bool addCourse(string code, string name) {
        for(Course &c : courses) if(c.code == code) return false;
        Course nc; nc.code = code; nc.name = name; nc.teacherID = "None";
        courses.push_back(nc); saveData(); return true;
    }

    bool removeCourse(string code) {
        auto it = remove_if(courses.begin(), courses.end(), [&](Course& c){ return c.code == code; });
        if(it != courses.end()) { courses.erase(it, courses.end()); saveData(); return true; }
        return false;
    }

    bool assignTeacher(string code, string tid) {
        bool teacherExists = false;
        for(User &u : users) if(u.id == tid && u.roleType == "Teacher") teacherExists = true;
        if(!teacherExists) return false;

        for(Course &c : courses) if(c.code == code) { c.teacherID = tid; saveData(); return true; }
        return false;
    }

    bool enrollStudent(string code, string sid) {
        bool studentExists = false;
        for(User &u : users) if(u.id == sid && u.roleType == "Student") studentExists = true;
        if(!studentExists) return false;

        for(Course &c : courses) {
            if(c.code == code) {
                for(string s : c.enrolledStudents) if(s == sid) return false; // Already enrolled
                c.enrolledStudents.push_back(sid); saveData(); return true;
            }
        }
        return false;
    }
};

#endif // LMS_DATA_H
