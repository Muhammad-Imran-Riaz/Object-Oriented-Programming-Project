#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QInputDialog>
#include <QDate> // Attendance ke liye date
#include <QVBoxLayout> // Layout ke liye
#include <QTabWidget>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // --- 1. WINDOW TITLE & TEXT UPDATES ---
    this->setWindowTitle("Bahria University Portal");

    // Box ke andar wala text change kiya
    ui->lblTitle->setText("LEARNING MANAGEMENT SYSTEM");

    // --- 2. NEW HEADING (Background par) ---
    // Naya label bana rahe hain jo box ke upar ayega
    QLabel *topHeading = new QLabel("BAHRIA UNIVERSITY ISLAMABAD");
    topHeading->setObjectName("lblMainHead"); // Is ID se hum color white karenge
    topHeading->setAlignment(Qt::AlignCenter);

    // Isay Login Page ke layout mein add kar rahe hain (Box se pehle)
    ui->l1->insertWidget(1, topHeading);


    // --- 3. UI ALIGNMENT (Centering) ---
    ui->loginFrame->setFixedWidth(450);
    ui->l1->setAlignment(ui->loginFrame, Qt::AlignCenter);

    ui->regFrame->setFixedWidth(450);
    ui->lReg->setAlignment(ui->regFrame, Qt::AlignCenter);

    ui->stackedWidget->setCurrentIndex(0);

    // --- 4. LOGIN BUTTONS SETUP ---
    ui->cmbRole->setVisible(false);
    ui->btnLogin->setVisible(false);

    QPushButton *btnStudent = new QPushButton("Login as Student");
    QPushButton *btnTeacher = new QPushButton("Login as Teacher");
    QPushButton *btnAdmin = new QPushButton("Login as Admin");

    // Styling with Hover
    QString baseStyle = "padding: 12px; font-weight: bold; border-radius: 5px; color: white;";

    btnStudent->setStyleSheet("QPushButton { background-color: #28a745; " + baseStyle + "} QPushButton:hover { background-color: #218838; }");
    btnTeacher->setStyleSheet("QPushButton { background-color: #0056b3; " + baseStyle + "} QPushButton:hover { background-color: #004494; }");
    btnAdmin->setStyleSheet("QPushButton { background-color: #343a40; " + baseStyle + "} QPushButton:hover { background-color: #1d2124; }");

    QHBoxLayout *btnLayout = new QHBoxLayout();
    btnLayout->addWidget(btnStudent);
    btnLayout->addWidget(btnTeacher);
    btnLayout->addWidget(btnAdmin);

    QVBoxLayout *frameLayout = qobject_cast<QVBoxLayout*>(ui->loginFrame->layout());
    if(frameLayout) frameLayout->addLayout(btnLayout);

    connect(btnStudent, &QPushButton::clicked, [this](){ performLogin("Student"); });
    connect(btnTeacher, &QPushButton::clicked, [this](){ performLogin("Teacher"); });
    connect(btnAdmin, &QPushButton::clicked, [this](){ performLogin("Admin"); });
}

MainWindow::~MainWindow() { delete ui; }

// --- LOGIN & REGISTER ---
void MainWindow::on_btnLogin_clicked() {
    string u = qstrToStd(ui->txtUsername->text());
    string p = qstrToStd(ui->txtPassword->text());
    string role = qstrToStd(ui->cmbRole->currentText());
    currentUser = lms.login(u, p, role);

    if (currentUser) {
        if (role == "Admin") ui->stackedWidget->setCurrentIndex(2);
        else if (role == "Student") {
            setupStudentDashboard();
            ui->stackedWidget->setCurrentIndex(3);
        }
        else if (role == "Teacher") {
            setupTeacherDashboard();
            ui->stackedWidget->setCurrentIndex(4);
        }
        QMessageBox::information(this, "Success", "Welcome " + stdToQstr(currentUser->name));
    }
}

void MainWindow::on_btnGoToRegister_clicked() { ui->stackedWidget->setCurrentIndex(1); }
void MainWindow::on_btnBackToLogin_clicked() { ui->stackedWidget->setCurrentIndex(0); }

void MainWindow::on_btnRegister_clicked() {
    string id = qstrToStd(ui->txtRegID->text());
    string name = qstrToStd(ui->txtRegName->text());
    string u = qstrToStd(ui->txtRegUser->text());
    string p = qstrToStd(ui->txtRegPass->text());
    string role = qstrToStd(ui->cmbRegRole->currentText());
    if(id.empty() || name.empty() || u.empty() || p.empty()) { QMessageBox::warning(this,"Error","Fill all fields"); return; }

    if(lms.registerUser(id, name, u, p, role)) {
        QMessageBox::information(this, "Success", "Registered! Please Login.");
        ui->stackedWidget->setCurrentIndex(0);
    } else QMessageBox::warning(this, "Error", "User already exists!");
}

// --- LOGOUTS ---
void MainWindow::on_btnAdminLogout_clicked() { ui->stackedWidget->setCurrentIndex(0); }
void MainWindow::on_btnStudentLogout_clicked() { ui->stackedWidget->setCurrentIndex(0); }
void MainWindow::on_btnTeacherLogout_clicked() { ui->stackedWidget->setCurrentIndex(0); }

// ================= ADMIN FUNCTIONS =================

// --- TAB 1: USERS ---
void MainWindow::on_btnViewStudents_clicked() {
    ui->listAdminUsers->clear();
    for(User &u : lms.users) if(u.roleType == "Student")
            ui->listAdminUsers->addItem(stdToQstr(u.id + " | " + u.name + " (" + u.username + ")"));
}

void MainWindow::on_btnViewTeachers_clicked() {
    ui->listAdminUsers->clear();
    for(User &u : lms.users) if(u.roleType == "Teacher")
            ui->listAdminUsers->addItem(stdToQstr(u.id + " | " + u.name + " (" + u.username + ")"));
}

void MainWindow::on_btnAddUser_clicked() {
    on_btnGoToRegister_clicked(); // Reusing the register page
}

void MainWindow::on_btnRemoveUser_clicked() {
    // 1. Pehle ye pooche ga: Student ya Teacher?
    QStringList items;
    items << "Student" << "Teacher";

    bool ok;
    QString role = QInputDialog::getItem(this, "Select Role",
                                         "Which one you want to remove?",
                                         items, 0, false, &ok);

    // Agar user ne OK press kiya (Cancel nahi kiya)
    if (ok && !role.isEmpty()) {

        // 2. Ab ID maange ga
        QString id = QInputDialog::getText(this, "Remove " + role,
                                           "Enter " + role + " ID:",
                                           QLineEdit::Normal, "", &ok);

        if (ok && !id.isEmpty()) {
            // Delete function call
            if (lms.removeUser(qstrToStd(id))) {
                QMessageBox::information(this, "Success", role + " removed successfully!");

                // List ko refresh karna zaroori hai taake name list se hat jaye
                if (role == "Student") on_btnViewStudents_clicked();
                else on_btnViewTeachers_clicked();

            } else {
                QMessageBox::warning(this, "Error", "Required Id is not found!");
            }
        }
    }
}

// --- TAB 2: COURSES ---
void MainWindow::on_btnViewCourses_clicked() {
    ui->listAdminCourses->clear();
    for(Course &c : lms.courses)
        ui->listAdminCourses->addItem(stdToQstr(c.code + " - " + c.name + " (T: " + c.teacherID + ")"));
}

void MainWindow::on_btnAddCourse_clicked() {
    bool ok;
    QString code = QInputDialog::getText(this, "New Course", "Enter Course Code:", QLineEdit::Normal, "", &ok);
    if(!ok || code.isEmpty()) return;
    QString name = QInputDialog::getText(this, "New Course", "Enter Course Name:", QLineEdit::Normal, "", &ok);

    if(lms.addCourse(qstrToStd(code), qstrToStd(name))) {
        QMessageBox::information(this, "Success", "Course Added!");
        on_btnViewCourses_clicked();
    } else QMessageBox::warning(this, "Error", "Course Code already exists!");
}

void MainWindow::on_btnRemoveCourse_clicked() {
    bool ok;
    QString code = QInputDialog::getText(this, "Remove Course", "Enter Course Code:", QLineEdit::Normal, "", &ok);
    if(ok && lms.removeCourse(qstrToStd(code))) {
        QMessageBox::information(this, "Success", "Course Removed.");
        on_btnViewCourses_clicked();
    } else QMessageBox::warning(this, "Error", "Course not found.");
}

void MainWindow::on_btnAssignTeacher_clicked() {
    bool ok;
    QString code = QInputDialog::getText(this, "Assign", "Enter Course Code:", QLineEdit::Normal, "", &ok);
    if(!ok) return;
    QString tid = QInputDialog::getText(this, "Assign", "Enter Teacher ID:", QLineEdit::Normal, "", &ok);

    if(lms.assignTeacher(qstrToStd(code), qstrToStd(tid))) QMessageBox::information(this,"Success","Teacher Assigned!");
    else QMessageBox::warning(this,"Error","Invalid Course or Teacher ID.");
}

void MainWindow::on_btnEnrollStudent_clicked() {
    bool ok;
    QString code = QInputDialog::getText(this, "Enroll", "Enter Course Code:", QLineEdit::Normal, "", &ok);
    if(!ok) return;
    QString sid = QInputDialog::getText(this, "Enroll", "Enter Student ID:", QLineEdit::Normal, "", &ok);

    if(lms.enrollStudent(qstrToStd(code), qstrToStd(sid))) QMessageBox::information(this,"Success","Student Enrolled!");
    else QMessageBox::warning(this,"Error","Invalid ID or Already Enrolled.");
}

// --- TAB 3: RECORDS ---
void MainWindow::on_btnViewAttendance_clicked() {
    ui->listAdminRecords->clear();
    ui->listAdminRecords->addItem("--- ALL COURSES ATTENDANCE ---");

    for(Course &c : lms.courses) {
        ui->listAdminRecords->addItem("Course: " + stdToQstr(c.code));
        if(c.attendance.empty()) {
            ui->listAdminRecords->addItem("  (No records)");
        } else {
            for(string &entry : c.attendance) {
                // Entry format "Date:StudentID:Status" ko clean dikhane ke liye:
                ui->listAdminRecords->addItem("  > " + stdToQstr(entry));
            }
        }
    }
}

void MainWindow::on_btnViewGrades_clicked() {
    ui->listAdminRecords->clear();
    ui->listAdminRecords->addItem("--- ALL STUDENT GRADES ---");

    for(Course &c : lms.courses) {
        ui->listAdminRecords->addItem("Course: " + stdToQstr(c.code));
        if(c.grades.empty()) {
            ui->listAdminRecords->addItem("  (No grades uploaded)");
        } else {
            for(string &g : c.grades) {
                // Entry format "StudentID:Grade"
                ui->listAdminRecords->addItem("  > ID: " + stdToQstr(g));
            }
        }
    }
}

// ================= TEACHER DASHBOARD LOGIC (UPDATED) =================

// --- HELPER FUNCTION (List dhoondne ke liye) ---
QListWidget* getList(QWidget* parent, QString name) {
    return parent->findChild<QListWidget*>(name);
}

// Helper for Input (Course Code)
QString askCourseCode(QWidget* p) {
    bool ok;
    QString code = QInputDialog::getText(p, "Course", "Enter Course Code:", QLineEdit::Normal, "", &ok);
    return ok ? code : "";
}

// --- SETUP UI (Admin Style Tabs & Lists) ---
void MainWindow::setupTeacherDashboard() {
    // Safety Checks
    if (!ui->pageTeacher) return;
    if (!ui->pageTeacher->layout()) {
        QVBoxLayout *mainLayout = new QVBoxLayout(ui->pageTeacher);
        ui->pageTeacher->setLayout(mainLayout);
    }
    QVBoxLayout *layout = qobject_cast<QVBoxLayout*>(ui->pageTeacher->layout());
    if (layout->count() > 2) return;

    // --- TABS SETUP ---
    QTabWidget *tabs = new QTabWidget();
    tabs->setStyleSheet(
        "QTabWidget::pane { border: 1px solid #D1D9E6; background: white; }"
        "QTabBar::tab { background: #E1E1E1; color: #333333; padding: 10px 20px; font-weight: bold; }"
        "QTabBar::tab:selected { background: white; color: #0056b3; border-top: 3px solid #0056b3; }"
        );

    QString btnStyle = "QPushButton { background-color: #0056b3; color: white; padding: 10px; border-radius: 5px; text-align: left; font-weight: bold; } QPushButton:hover { background-color: #004494; }";

    // === TAB 1: COURSES ===
    QWidget *tabCourses = new QWidget();
    QHBoxLayout *hCourses = new QHBoxLayout(tabCourses);

    QWidget *leftC = new QWidget();
    QVBoxLayout *vBtnC = new QVBoxLayout(leftC);
    QPushButton *btnViewC = new QPushButton("View My Courses"); btnViewC->setStyleSheet(btnStyle);
    QPushButton *btnViewS = new QPushButton("View Enrolled Students"); btnViewS->setStyleSheet(btnStyle);
    vBtnC->addWidget(btnViewC);
    vBtnC->addWidget(btnViewS);
    vBtnC->addStretch();

    QListWidget *listCourses = new QListWidget();
    listCourses->setObjectName("listTeacherCourses"); // ID di hai taake dhoond sakein

    hCourses->addWidget(leftC, 1);
    hCourses->addWidget(listCourses, 3);
    tabs->addTab(tabCourses, "My Courses");

    // === TAB 2: ATTENDANCE ===
    QWidget *tabAtt = new QWidget();
    QHBoxLayout *hAtt = new QHBoxLayout(tabAtt);

    QWidget *leftA = new QWidget();
    QVBoxLayout *vBtnA = new QVBoxLayout(leftA);
    QPushButton *btnMarkAtt = new QPushButton("Mark Attendance"); btnMarkAtt->setStyleSheet(btnStyle);
    vBtnA->addWidget(btnMarkAtt);
    vBtnA->addStretch();

    QListWidget *listAtt = new QListWidget();
    listAtt->setObjectName("listTeacherAttendance");

    hAtt->addWidget(leftA, 1);
    hAtt->addWidget(listAtt, 3);
    tabs->addTab(tabAtt, "Attendance");

    // === TAB 3: UPLOADS ===
    QWidget *tabUp = new QWidget();
    QHBoxLayout *hUp = new QHBoxLayout(tabUp);

    QWidget *leftU = new QWidget();
    QVBoxLayout *vBtnUp = new QVBoxLayout(leftU);
    QPushButton *btnLec = new QPushButton("Upload Lecture"); btnLec->setStyleSheet(btnStyle);
    QPushButton *btnAss = new QPushButton("Upload Assignment"); btnAss->setStyleSheet(btnStyle);
    vBtnUp->addWidget(btnLec);
    vBtnUp->addWidget(btnAss);
    vBtnUp->addStretch();

    QListWidget *listUp = new QListWidget();
    listUp->setObjectName("listTeacherUploads");

    hUp->addWidget(leftU, 1);
    hUp->addWidget(listUp, 3);
    tabs->addTab(tabUp, "Uploads");

    // === TAB 4: GRADES ===
    QWidget *tabGrade = new QWidget();
    QHBoxLayout *hGrade = new QHBoxLayout(tabGrade);

    QWidget *leftG = new QWidget();
    QVBoxLayout *vBtnG = new QVBoxLayout(leftG);
    QPushButton *btnGrade = new QPushButton("Upload Grades"); btnGrade->setStyleSheet(btnStyle);
    QPushButton *btnFeed = new QPushButton("View Feedbacks"); btnFeed->setStyleSheet(btnStyle);
    vBtnG->addWidget(btnGrade);
    vBtnG->addWidget(btnFeed);
    vBtnG->addStretch();

    QListWidget *listGrade = new QListWidget();
    listGrade->setObjectName("listTeacherGrades");

    hGrade->addWidget(leftG, 1);
    hGrade->addWidget(listGrade, 3);
    tabs->addTab(tabGrade, "Grades");

    // --- CONNECTIONS ---
    connect(btnViewC, &QPushButton::clicked, this, &MainWindow::teacherViewCourses);
    connect(btnViewS, &QPushButton::clicked, this, &MainWindow::teacherViewStudents);
    connect(btnMarkAtt, &QPushButton::clicked, this, &MainWindow::teacherAttendance);
    connect(btnLec, &QPushButton::clicked, this, &MainWindow::teacherUploadLecture);
    connect(btnAss, &QPushButton::clicked, this, &MainWindow::teacherUploadAssignment);
    connect(btnGrade, &QPushButton::clicked, this, &MainWindow::teacherUploadGrade);
    connect(btnFeed, &QPushButton::clicked, this, &MainWindow::teacherFeedbacks);

    if (layout) layout->insertWidget(1, tabs);
}


// --- LOGIC FUNCTIONS (LIST MEIN SHOW KARNE WALE) ---

// 1. View Assigned Courses
void MainWindow::teacherViewCourses() {
    QListWidget *list = getList(ui->pageTeacher, "listTeacherCourses");
    if(!list) return;

    list->clear();
    list->addItem("--- MY ASSIGNED COURSES ---");

    bool found = false;
    for(Course &c : lms.courses) {
        if(c.teacherID == currentUser->id) {
            list->addItem(stdToQstr(c.code + " - " + c.name));
            found = true;
        }
    }
    if(!found) list->addItem("No courses assigned yet.");
}

// 2. View Enrolled Students
void MainWindow::teacherViewStudents() {
    QListWidget *list = getList(ui->pageTeacher, "listTeacherCourses");
    if(!list) return;

    string code = qstrToStd(askCourseCode(this));
    if(code.empty()) return;

    list->clear();
    list->addItem("--- STUDENTS ENROLLED IN " + stdToQstr(code) + " ---");

    bool courseFound = false;
    for(Course &c : lms.courses) {
        if(c.code == code && c.teacherID == currentUser->id) {
            courseFound = true;
            if(c.enrolledStudents.empty()) list->addItem("No students enrolled.");
            else {
                for(string s : c.enrolledStudents) {
                    string sName = "Unknown";
                    for(User &u : lms.users) if(u.id == s) sName = u.name;
                    list->addItem(stdToQstr(s + " | " + sName));
                }
            }
            break;
        }
    }
    if(!courseFound) list->addItem("Error: Course not found or Access Denied.");
}

// 3. Mark Attendance (FIXED)
void MainWindow::teacherAttendance() {
    QListWidget *list = getList(ui->pageTeacher, "listTeacherAttendance");
    if(list) list->clear();

    string code = qstrToStd(askCourseCode(this));
    if(code.empty()) return;

    for(Course &c : lms.courses) {
        if(c.code == code && c.teacherID == currentUser->id) {
            bool ok;
            QString sid = QInputDialog::getText(this, "Attendance", "Enter Student ID:", QLineEdit::Normal, "", &ok);
            if(!ok || sid.isEmpty()) return;

            QString status = QInputDialog::getItem(this, "Status", "Mark Status:", {"Present", "Absent"}, 0, false, &ok);
            if(!ok) return;

            string date = QDate::currentDate().toString("dd-MM-yyyy").toStdString();
            string entry = date + ":" + qstrToStd(sid) + ":" + qstrToStd(status);

            c.attendance.push_back(entry);
            lms.saveData();

            if(list) {
                list->addItem("--- ATTENDANCE LOG ---");
                list->addItem("Marked: " + sid + " is " + status);
                list->addItem("Date: " + stdToQstr(date));
            }
            return;
        }
    }
    if(list) list->addItem("Error: Invalid Course or Access Denied.");
}

// 4. Upload Lecture
void MainWindow::teacherUploadLecture() {
    QListWidget *list = getList(ui->pageTeacher, "listTeacherUploads");
    if(list) list->clear();

    string code = qstrToStd(askCourseCode(this));
    if(code.empty()) return;

    for(Course &c : lms.courses) {
        if(c.code == code && c.teacherID == currentUser->id) {
            bool ok;
            QString title = QInputDialog::getText(this, "Lecture", "Enter Lecture Title:", QLineEdit::Normal, "", &ok);
            if(ok && !title.isEmpty()) {
                c.lectures.push_back(qstrToStd(title));
                lms.saveData();
                if(list) list->addItem("Success: Lecture '" + title + "' added.");
            }
            return;
        }
    }
    if(list) list->addItem("Error: Invalid Course.");
}

// 5. Upload Assignment
void MainWindow::teacherUploadAssignment() {
    QListWidget *list = getList(ui->pageTeacher, "listTeacherUploads");
    if(list) list->clear();

    string code = qstrToStd(askCourseCode(this));
    if(code.empty()) return;

    for(Course &c : lms.courses) {
        if(c.code == code && c.teacherID == currentUser->id) {
            bool ok;
            QString title = QInputDialog::getText(this, "Assignment", "Enter Assignment Title:", QLineEdit::Normal, "", &ok);
            if(ok && !title.isEmpty()) {
                c.assignments.push_back(qstrToStd(title));
                lms.saveData();
                if(list) list->addItem("Success: Assignment '" + title + "' posted.");
            }
            return;
        }
    }
    if(list) list->addItem("Error: Invalid Course.");
}

// 6. Upload Grade
void MainWindow::teacherUploadGrade() {
    QListWidget *list = getList(ui->pageTeacher, "listTeacherGrades");
    if(list) list->clear();

    string code = qstrToStd(askCourseCode(this));
    if(code.empty()) return;

    for(Course &c : lms.courses) {
        if(c.code == code && c.teacherID == currentUser->id) {
            bool ok;
            QString sid = QInputDialog::getText(this, "Grade", "Enter Student ID:", QLineEdit::Normal, "", &ok);
            if(!ok) return;
            QString grade = QInputDialog::getText(this, "Grade", "Enter Grade:", QLineEdit::Normal, "", &ok);

            if(ok && !grade.isEmpty()) {
                c.grades.push_back(qstrToStd(sid) + ":" + qstrToStd(grade));
                lms.saveData();
                if(list) list->addItem("Success: Grade " + grade + " assigned to " + sid);
            }
            return;
        }
    }
    if(list) list->addItem("Error: Invalid Course.");
}

// 7. View Feedbacks
void MainWindow::teacherFeedbacks() {
    QListWidget *list = getList(ui->pageTeacher, "listTeacherGrades");
    if(list) {
        list->clear();
        list->addItem("--- STUDENT FEEDBACKS ---");
        list->addItem("No new feedbacks available.");
    }
}
// ================= STUDENT DASHBOARD LOGIC =================

void MainWindow::setupStudentDashboard() {
    // 1. Safety & Layout Checks
    if (!ui->pageStudent) return;
    if (!ui->pageStudent->layout()) {
        QVBoxLayout *mainLayout = new QVBoxLayout(ui->pageStudent);
        ui->pageStudent->setLayout(mainLayout);
    }
    QVBoxLayout *layout = qobject_cast<QVBoxLayout*>(ui->pageStudent->layout());
    if (layout->count() > 2) return; // Agar pehle se bana hai to wapis jao

    // --- TABS SETUP ---
    QTabWidget *tabs = new QTabWidget();
    tabs->setStyleSheet(
        "QTabWidget::pane { border: 1px solid #D1D9E6; background: white; }"
        "QTabBar::tab { background: #E1E1E1; color: #333333; padding: 10px 20px; font-weight: bold; }"
        "QTabBar::tab:selected { background: white; color: #0056b3; border-top: 3px solid #0056b3; }"
        );

    QString btnStyle = "QPushButton { background-color: #0056b3; color: white; padding: 10px; border-radius: 5px; text-align: left; font-weight: bold; } QPushButton:hover { background-color: #004494; }";

    // === TAB 1: ACADEMICS (Courses, Lectures, Assignments) ===
    QWidget *tabAcad = new QWidget();
    QHBoxLayout *hAcad = new QHBoxLayout(tabAcad);

    QWidget *left1 = new QWidget();
    QVBoxLayout *vBtn1 = new QVBoxLayout(left1);
    QPushButton *btnC = new QPushButton("View Registered Courses"); btnC->setStyleSheet(btnStyle);
    QPushButton *btnL = new QPushButton("View Lectures"); btnL->setStyleSheet(btnStyle);
    QPushButton *btnA = new QPushButton("View Assignments"); btnA->setStyleSheet(btnStyle);
    vBtn1->addWidget(btnC);
    vBtn1->addWidget(btnL);
    vBtn1->addWidget(btnA);
    vBtn1->addStretch();

    QListWidget *listAcad = new QListWidget();
    listAcad->setObjectName("listStudentAcad"); // ID for logic

    hAcad->addWidget(left1, 1);
    hAcad->addWidget(listAcad, 3);
    tabs->addTab(tabAcad, "Academics");

    // === TAB 2: PERFORMANCE (Attendance, Grades) ===
    QWidget *tabPerf = new QWidget();
    QHBoxLayout *hPerf = new QHBoxLayout(tabPerf);

    QWidget *left2 = new QWidget();
    QVBoxLayout *vBtn2 = new QVBoxLayout(left2);
    QPushButton *btnAtt = new QPushButton("Check Attendance"); btnAtt->setStyleSheet(btnStyle);
    QPushButton *btnGrd = new QPushButton("View Grades"); btnGrd->setStyleSheet(btnStyle);
    vBtn2->addWidget(btnAtt);
    vBtn2->addWidget(btnGrd);
    vBtn2->addStretch();

    QListWidget *listPerf = new QListWidget();
    listPerf->setObjectName("listStudentPerf");

    hPerf->addWidget(left2, 1);
    hPerf->addWidget(listPerf, 3);
    tabs->addTab(tabPerf, "Performance");

    // === TAB 3: PROFILE & OTHER ===
    QWidget *tabProf = new QWidget();
    QHBoxLayout *hProf = new QHBoxLayout(tabProf);

    QWidget *left3 = new QWidget();
    QVBoxLayout *vBtn3 = new QVBoxLayout(left3);
    QPushButton *btnProf = new QPushButton("View Profile"); btnProf->setStyleSheet(btnStyle);
    QPushButton *btnFeed = new QPushButton("Give Feedback"); btnFeed->setStyleSheet(btnStyle);
    vBtn3->addWidget(btnProf);
    vBtn3->addWidget(btnFeed);
    vBtn3->addStretch();

    QListWidget *listProf = new QListWidget();
    listProf->setObjectName("listStudentProf");

    hProf->addWidget(left3, 1);
    hProf->addWidget(listProf, 3);
    tabs->addTab(tabProf, "My Profile");


    // --- CONNECTIONS ---
    connect(btnC, &QPushButton::clicked, this, &MainWindow::studentViewCourses);
    connect(btnL, &QPushButton::clicked, this, &MainWindow::studentViewLectures);
    connect(btnA, &QPushButton::clicked, this, &MainWindow::studentViewAssignments);
    connect(btnAtt, &QPushButton::clicked, this, &MainWindow::studentCheckAttendance);
    connect(btnGrd, &QPushButton::clicked, this, &MainWindow::studentViewGrades);
    connect(btnProf, &QPushButton::clicked, this, &MainWindow::studentViewProfile);
    connect(btnFeed, &QPushButton::clicked, this, &MainWindow::studentGiveFeedback);

    // Add to Page
    if (layout) layout->insertWidget(1, tabs);
}

// --- STUDENT LOGIC FUNCTIONS ---

// 1. View Registered Courses
void MainWindow::studentViewCourses() {
    QListWidget *list = getList(ui->pageStudent, "listStudentAcad");
    if(!list) return;
    list->clear();
    list->addItem("--- MY REGISTERED COURSES ---");

    bool found = false;
    for(Course &c : lms.courses) {
        // Check agar student is course mein enrolled hai
        for(string &sid : c.enrolledStudents) {
            if(sid == currentUser->id) {
                list->addItem(stdToQstr(c.code + " - " + c.name + " (Teacher: " + c.teacherID + ")"));
                found = true;
                break;
            }
        }
    }
    if(!found) list->addItem("You are not enrolled in any course.");
}

// 2. View Lectures
void MainWindow::studentViewLectures() {
    QListWidget *list = getList(ui->pageStudent, "listStudentAcad");
    if(!list) return;

    string code = qstrToStd(askCourseCode(this));
    if(code.empty()) return;

    list->clear();
    list->addItem("--- LECTURES FOR " + stdToQstr(code) + " ---");

    for(Course &c : lms.courses) {
        if(c.code == code) {
            // Validate enrollment
            bool isEnrolled = false;
            for(string s : c.enrolledStudents) if(s == currentUser->id) isEnrolled = true;

            if(!isEnrolled) {
                list->addItem("Error: You are not enrolled in this course.");
                return;
            }

            if(c.lectures.empty()) list->addItem("No lectures uploaded yet.");
            for(string l : c.lectures) list->addItem(stdToQstr(l));
            return;
        }
    }
    list->addItem("Error: Course not found.");
}

// 3. View Assignments
void MainWindow::studentViewAssignments() {
    QListWidget *list = getList(ui->pageStudent, "listStudentAcad");
    if(!list) return;

    string code = qstrToStd(askCourseCode(this));
    if(code.empty()) return;

    list->clear();
    list->addItem("--- ASSIGNMENTS FOR " + stdToQstr(code) + " ---");

    for(Course &c : lms.courses) {
        if(c.code == code) {
            bool isEnrolled = false;
            for(string s : c.enrolledStudents) if(s == currentUser->id) isEnrolled = true;

            if(!isEnrolled) {
                list->addItem("Error: You are not enrolled in this course.");
                return;
            }

            if(c.assignments.empty()) list->addItem("No assignments uploaded yet.");
            for(string a : c.assignments) list->addItem(stdToQstr(a));
            return;
        }
    }
    list->addItem("Error: Course not found.");
}

// 4. Check Attendance
void MainWindow::studentCheckAttendance() {
    QListWidget *list = getList(ui->pageStudent, "listStudentPerf");
    if(!list) return;

    string code = qstrToStd(askCourseCode(this));
    if(code.empty()) return;

    list->clear();
    list->addItem("--- ATTENDANCE RECORD FOR " + stdToQstr(code) + " ---");

    for(Course &c : lms.courses) {
        if(c.code == code) {
            // Data format: "Date:StudentID:Status"
            bool foundAny = false;
            for(string entry : c.attendance) {
                stringstream ss(entry);
                string date, sid, status;
                getline(ss, date, ':');
                getline(ss, sid, ':');
                getline(ss, status, ':');

                if(sid == currentUser->id) {
                    list->addItem(stdToQstr(date + " - " + status));
                    foundAny = true;
                }
            }
            if(!foundAny) list->addItem("No attendance records found.");
            return;
        }
    }
    list->addItem("Error: Course not found.");
}

// 5. View Grades
void MainWindow::studentViewGrades() {
    QListWidget *list = getList(ui->pageStudent, "listStudentPerf");
    if(!list) return;

    string code = qstrToStd(askCourseCode(this));
    if(code.empty()) return;

    list->clear();
    list->addItem("--- GRADES FOR " + stdToQstr(code) + " ---");

    for(Course &c : lms.courses) {
        if(c.code == code) {
            // Data format: "StudentID:Grade"
            bool found = false;
            for(string entry : c.grades) {
                stringstream ss(entry);
                string sid, grade;
                getline(ss, sid, ':');
                getline(ss, grade, ':');

                if(sid == currentUser->id) {
                    list->addItem("Grade Awarded: " + stdToQstr(grade));
                    found = true;
                }
            }
            if(!found) list->addItem("No grades uploaded yet.");
            return;
        }
    }
    list->addItem("Error: Course not found.");
}

// 6. View Profile
void MainWindow::studentViewProfile() {
    QListWidget *list = getList(ui->pageStudent, "listStudentProf");
    if(!list) return;
    list->clear();
    list->addItem("--- MY PROFILE ---");
    list->addItem("Name: " + stdToQstr(currentUser->name));
    list->addItem("User ID: " + stdToQstr(currentUser->id));
    list->addItem("Username: " + stdToQstr(currentUser->username));
    list->addItem("Role: Student");
}

// 7. Give Feedback
void MainWindow::studentGiveFeedback() {
    bool ok;
    QString feedback = QInputDialog::getText(this, "Feedback", "Enter your feedback for admin/teachers:", QLineEdit::Normal, "", &ok);
    if(ok && !feedback.isEmpty()) {
        QMessageBox::information(this, "Sent", "Feedback sent successfully!");
        // Asal project mein isay file mein save krte, abhi k liye sirf popup kafi ha
    }
}

// ================= WELCOME MESSAGE HELPER =================

void MainWindow::updateWelcomeMessage(QWidget* page, QString name) {
    if (!page || !page->layout()) return;

    QVBoxLayout *layout = qobject_cast<QVBoxLayout*>(page->layout());
    if (!layout) return;

    // 1. Check karein ke kya Name Label pehle se bana hua hai?
    QLabel *nameLabel = page->findChild<QLabel*>("lblWelcomeName");

    if (!nameLabel) {
        // Agar nahi bana, to naya banayen
        nameLabel = new QLabel();
        nameLabel->setObjectName("lblWelcomeName"); // ID set ki taake baad mein dhoond sakein

        // Styling: Cyan Color (Blue bg par acha lagega), Thora chota font
        nameLabel->setStyleSheet(
            "color: #00d2ff; "           // Cyan/Light Blue text
            "font-size: 18px; "          // Heading se thora chota
            "font-weight: bold; "
            "qproperty-alignment: AlignCenter; " // Center align
            "padding-bottom: 10px;"
            );

        // Heading (Index 0) ke foran baad add karein (Index 1)
        layout->insertWidget(1, nameLabel);
    }

    // 2. Text Update Karein
    nameLabel->setText( name);
}

// ================= LOGIN HELPER FUNCTION (FIXED) =================
// Ye function end mein is liye hai taake updateWelcomeMessage use kar sake

// ================= LOGIN HELPER FUNCTION (NO POPUP) =================

void MainWindow::performLogin(string role) {
    // Input fields se data uthana
    string u = qstrToStd(ui->txtUsername->text());
    string p = qstrToStd(ui->txtPassword->text());

    // Validation
    if(u.empty() || p.empty()) {
        QMessageBox::warning(this, "Login Failed", "Please enter Username and Password.");
        return;
    }

    // Check Login via LMS
    currentUser = lms.login(u, p, role);

    if (currentUser) {
        QString qName = stdToQstr(currentUser->name);

        if (role == "Admin") {
            ui->stackedWidget->setCurrentIndex(2);
            updateWelcomeMessage(ui->pageAdmin, qName);
        }
        else if (role == "Student") {
            setupStudentDashboard();
            ui->stackedWidget->setCurrentIndex(3);
            updateWelcomeMessage(ui->pageStudent, qName);
        }
        else if (role == "Teacher") {
            setupTeacherDashboard();
            ui->stackedWidget->setCurrentIndex(4);
            updateWelcomeMessage(ui->pageTeacher, qName);
        }


    } else {
        // Error abhi bhi dikhayega agar password ghalat ho
        QMessageBox::warning(this, "Login Failed", "Invalid Credentials for " + stdToQstr(role));
    }
}
