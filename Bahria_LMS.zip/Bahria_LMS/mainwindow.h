#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "lms_data.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    // Login & Reg
    void on_btnLogin_clicked();
    void on_btnGoToRegister_clicked();
    void on_btnRegister_clicked();
    void on_btnBackToLogin_clicked();

    // --- TEACHER FUNCTIONS (Renamed to fix warnings) ---
    void setupTeacherDashboard();
    void teacherViewCourses();      // Pehle: on_btnT_ViewCourses_clicked
    void teacherAttendance();       // Pehle: on_btnT_Attendance_clicked
    void teacherUploadLecture();    // Pehle: on_btnT_UploadLecture_clicked
    void teacherUploadAssignment(); // Pehle: on_btnT_UploadAssignment_clicked
    void teacherUploadGrade();      // Pehle: on_btnT_UploadGrade_clicked
    void teacherViewStudents();     // Pehle: on_btnT_ViewStudents_clicked
    void teacherFeedbacks();        // Pehle: on_btnT_Feedbacks_clicked

    // --- STUDENT FUNCTIONS (Add these) ---
    void setupStudentDashboard();
    void studentViewCourses();
    void studentCheckAttendance();
    void studentViewLectures();
    void studentViewAssignments();
    void studentViewGrades();
    void studentGiveFeedback();
    void studentViewProfile();

    // Logouts
    void on_btnAdminLogout_clicked();
    void on_btnStudentLogout_clicked();
    void on_btnTeacherLogout_clicked();

    // Admin - Users Tab
    void on_btnViewStudents_clicked();
    void on_btnViewTeachers_clicked();
    void on_btnAddUser_clicked();
    void on_btnRemoveUser_clicked();

    // Admin - Courses Tab
    void on_btnViewCourses_clicked();
    void on_btnAddCourse_clicked();
    void on_btnRemoveCourse_clicked();
    void on_btnAssignTeacher_clicked();
    void on_btnEnrollStudent_clicked();

    // Admin - Records Tab
    void on_btnViewAttendance_clicked();
    void on_btnViewGrades_clicked();

private:
    Ui::MainWindow *ui;
    LMS lms;
    User* currentUser;
    void performLogin(string role);
    void updateWelcomeMessage(QWidget* page, QString name);
};
#endif // MAINWINDOW_H
